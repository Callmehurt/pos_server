const allowedOrigins = [
  'http://localhost:3000',
  'http://192.168.10.108:52608',
  'http://192.168.10.108:3000'
];

module.exports = allowedOrigins;