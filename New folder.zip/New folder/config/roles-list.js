const RolesList = {
    "Admin": 5150,
    "Editor": 5151,
    "User": 5152,
}

module.exports = RolesList;